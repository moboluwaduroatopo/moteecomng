
   
<div class="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <p class="mb-4"><img src="{{ asset('images/logon.png') }}" alt="Image" class="img-fluid"></p>
          <p>Nigerian Universities Engineering Students’ Association (NUESA) National Body is the students wing of Nigerian Society of Engineers (NSE). 
            {{-- This is the National, Active, Progressive and Democratic Association formed for the sole purpose of promoting the welfare and interest of her members. </p>   --}}
          </p>
            <p><a href="about">Learn More</a></p>
        </div>
        <div class="col-lg-3">
          <h3 class="footer-heading"><span>About Us</span></h3>
          <ul class="list-unstyled">
              {{-- <li><a href="#">Acedemic</a></li> --}}
              <li><a href="#news">News</a></li>
              <li><a href="comingsoon">Our Interns</a></li>
              <li><a href="comingsoon">Our Leadership</a></li>
              <!-- <li><a href="#">Careers</a></li>
              <li><a href="#">Human Resources</a></li> -->
          </ul>
        </div>
        <div class="col-lg-3">
            <h3 class="footer-heading"><span>Meet Excution</span></h3>
            <ul class="list-unstyled">
                <li><a href="#Present">2020</a></li>
                <li><a href="comingsoon">2019</a></li>
                <li><a href="comingsoon">2018</a></li>
                <li><a href="comingsoon">2017</a></li>
               <!--  <li><a href="#">Business Administration</a></li>
                <li><a href="#">Computer Science</a></li> -->
            </ul>
        </div>
        <div class="col-lg-3">
            <h3 class="footer-heading"><span>Contact</span></h3>
            <ul class="list-unstyled">
                <li><a href="https://api.whatsapp.com/send?phone=2348163279885&text=I am coming from NUESA website." class="nav-link text-left"">President</a></li>
                <!-- <li><a href="#">Support Community</a></li>
                <li><a href="#">Press</a></li>
                <li><a href="#">Share Your Story</a></li>
                <li><a href="#">Our Supporters</a></li> -->
            </ul>
        </div>
      </div>

      <div class="row">
        <div class="col-12">
          <div class="copyright">
              <p>
                  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  Copyright &copy;<script>document.write(new Date().getFullYear());</script> <i class="icon-heart" aria-hidden="true"></i> by <a href="https://motee.com.ng" target="_blank" >MOTEE</a>
                  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                  </p>
          </div>
        </div>
      </div>
    </div>
  </div>
