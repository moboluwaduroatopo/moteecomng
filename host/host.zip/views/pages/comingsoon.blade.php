@extends('layouts.app')

@section('content')

<div class="site-section ftco-subscribe-1 site-blocks-cover pb-4" style="background-image: url('images/bg_1.jpg')">
  <div class="container">
    <div class="row align-items-end justify-content-center text-center">
      <div class="col-lg-7">
        <h2 class="mb-0">Coming Soon</h2>
        {{-- <p>Lorem ipsum dolor sit amet consectetur adipisicing.</p> --}}
      </div>
    </div>
  </div>
</div> 
<br>
<div class="container">
	<div class="card">
  <div class="card-body text-uppercase">Sorry, Coming Soon ............................................</div>
</div>
</div>
@endsection