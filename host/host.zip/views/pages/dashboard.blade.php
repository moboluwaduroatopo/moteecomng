@extends('layouts.dashapp')
@section('content')


<p>dashbroad</p>
@endsection
