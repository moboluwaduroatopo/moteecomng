@extends('layouts.dashapp')
@section('my-content')
<h3>Welcome to about page</h3>


@endsection