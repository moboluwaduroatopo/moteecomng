@extends('layouts.oldapp')
@section('my-content')
<h3 class="text-center">Welcome to </h3>

@endsection