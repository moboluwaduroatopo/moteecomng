	@extends('layouts.app')

@section('content')
	<section>
		<div class="container">
			<div class="row">
				 
				
                
				<div class="col-sm-9 padding-right">
					<div class="alert alert-success">
					   <h3 class="text-center"><i class="fa fa-check-circle fa-lg"></i> Your Chapter's has been submitted! Thank you !</h3>
					<h3 class="text-center">Your  Chapter's id  @include('includes.id')</h3>
                    </div>
				</div>
				
			</div>
		</div>
		</div>
	</section>
	@endsection